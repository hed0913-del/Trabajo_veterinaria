package dao;

/** DAO específico para la tabla consultas. */
public class ConsultaDAO extends BaseDAO {
    public ConsultaDAO() { super("consultas", "id"); }
}
