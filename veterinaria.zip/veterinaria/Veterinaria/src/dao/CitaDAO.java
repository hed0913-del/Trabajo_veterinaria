package dao;

/** DAO específico para la tabla citas. */
public class CitaDAO extends BaseDAO {
    public CitaDAO() { super("citas", "id"); }
}
