package dao;

/** DAO específico para la tabla mascotas. */
public class MascotaDAO extends BaseDAO {
    public MascotaDAO() { super("mascotas", "id"); }
}
