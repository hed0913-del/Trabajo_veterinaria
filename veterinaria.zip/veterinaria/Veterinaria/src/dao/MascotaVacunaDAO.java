package dao;

/** DAO específico para la tabla mascota_vacunas. */
public class MascotaVacunaDAO extends BaseDAO {
    public MascotaVacunaDAO() { super("mascota_vacunas", "id"); }
}
