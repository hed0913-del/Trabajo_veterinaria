package dao;

/** DAO específico para la tabla duenos. */
public class DuenoDAO extends BaseDAO {
    public DuenoDAO() { super("duenos", "id"); }
}
