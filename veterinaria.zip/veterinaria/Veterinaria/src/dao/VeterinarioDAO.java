package dao;

/** DAO específico para la tabla veterinarios. */
public class VeterinarioDAO extends BaseDAO {
    public VeterinarioDAO() { super("veterinarios", "id"); }
}
