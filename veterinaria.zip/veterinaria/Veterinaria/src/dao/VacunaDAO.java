package dao;

/** DAO específico para la tabla vacunas. */
public class VacunaDAO extends BaseDAO {
    public VacunaDAO() { super("vacunas", "id"); }
}
